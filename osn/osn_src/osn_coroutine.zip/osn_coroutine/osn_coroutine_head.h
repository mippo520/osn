//
//  osn_coroutine_head.h
//  osn
//
//  Created by liqing on 17/4/10.
//  Copyright © 2017年 liqing. All rights reserved.
//

#ifndef osn_coroutine_head_h
#define osn_coroutine_head_h

#include <functional>
#include <ucontext.h>
#include "osn.h"

typedef oINT32 OSN_CO_ARG;

typedef std::function<void (OSN_CO_ARG)> OSN_COROUTINE_FUNC;

enum eCoroutineState
{
    eCS_None = 0,
    eCS_Ready,
    eCS_Running,
    eCS_Suspend,
};

#endif /* osn_coroutine_head_h */
