//
//  osn_coroutine_manager.cpp
//  osn
//
//  Created by liqing on 17/4/10.
//  Copyright © 2017年 liqing. All rights reserved.
//


#include "osn_coroutine_manager.h"
#include "osn_coroutine.h"
#include <stdio.h>

OsnCoroutineManager::OsnCoroutineManager()
    : m_nRunning(-1)
{
}

OsnCoroutineManager::~OsnCoroutineManager()
{
    
}

oINT32 OsnCoroutineManager::create(const OSN_COROUTINE_FUNC &func)
{
    oINT32 nId = makeObj<OsnCoroutine>();
    OsnCoroutine *pCo = getObject(nId);
    if (NULL != pCo) {
        pCo->setFunc(func);
        pCo->setState(eCS_Ready);
    }
    return nId;
}

void OsnCoroutineManager::yield()
{
    if (!isRunning()) {
        return;
    }
    
    OsnCoroutine *pCo = getObject(m_nRunning);
    if (NULL == pCo) {
        return;
    }

    pCo->setState(eCS_Suspend);
    m_nRunning = -1;
    
    swapcontext(pCo->getCtxPtr(), &m_MainCtx);
}

void OsnCoroutineManager::resume(oINT32 nId)
{
    if (isRunning()) {
        return;
    }
    
    OsnCoroutine *pCo = getObject(nId);
    if (NULL == pCo) {
        return;
    }

    switch (pCo->getState()) {
        case eCS_Ready:
            getcontext(pCo->getCtxPtr());
            pCo->createContext(&m_MainCtx);
            pCo->setState(eCS_Running);
            m_nRunning = nId;
            makecontext(pCo->getCtxPtr(), (void (*)())OsnCoroutineManager::mainFunc, 1, this);
            swapcontext(&m_MainCtx, pCo->getCtxPtr());
            break;
        case eCS_Suspend:
            pCo->setState(eCS_Running);
            m_nRunning = nId;
            swapcontext(&m_MainCtx, pCo->getCtxPtr());
            break;
        default:

            break;
    }
}

oBOOL OsnCoroutineManager::isRunning()
{
    return -1 != m_nRunning;
}

void OsnCoroutineManager::mainFunc(OsnCoroutineManager *pManager)
{
    if (NULL == pManager) {
        return;
    }
    OsnCoroutine *pCo = pManager->getObject(pManager->m_nRunning);
    if (NULL == pCo) {
        return;
    }
    
    pCo->run();
    pManager->removeObj(pManager->m_nRunning);
    pManager->m_nRunning = -1;
}

