//
//  osn_coroutine_manager.hpp
//  osn
//
//  Created by liqing on 17/4/10.
//  Copyright © 2017年 liqing. All rights reserved.
//

#ifndef osn_coroutine_manager_hpp
#define osn_coroutine_manager_hpp
#include "osn_coroutine_head.h"
#include "osn.h"
#include "osn_arr_manager.h"

class OsnCoroutine;

class OsnCoroutineManager : public OsnArrManager<OsnCoroutine> {
    static void mainFunc(OsnCoroutineManager *pManager);
public:
    OsnCoroutineManager();
    ~OsnCoroutineManager();
    
    oINT32 create(const OSN_COROUTINE_FUNC &func);
    void yield();
    void resume(oINT32 nId);
    oBOOL isRunning();
private:
    void doS() {}
private:
    oINT32 m_nRunning;
    ucontext_t m_MainCtx;
};

#endif /* osn_coroutine_manager_hpp */
