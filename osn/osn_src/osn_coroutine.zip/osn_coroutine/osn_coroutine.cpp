//
//  osn_coroutine.cpp
//  osn
//
//  Created by liqing on 17/4/10.
//  Copyright © 2017年 liqing. All rights reserved.
//

#include "osn_coroutine.h"
#include <stdlib.h>

OsnCoroutine::OsnCoroutine()
    : m_pszStack(NULL)
    , m_nStackSize(0)
    , m_nStackCap(0)
{
}

OsnCoroutine::~OsnCoroutine()
{
    
}


void OsnCoroutine::init()
{
}

void OsnCoroutine::exit()
{
    
}

void OsnCoroutine::createContext(ucontext_t *pNextCtx)
{
    getcontext(&m_Ctx);

    m_Ctx.uc_stack.ss_sp = m_szStack;
    m_Ctx.uc_stack.ss_size = 32 * 1024;
    m_Ctx.uc_link = pNextCtx;
}


ucontext_t* OsnCoroutine::getCtxPtr()
{
    return &m_Ctx;
}


void OsnCoroutine::run()
{
    m_Func(10);
}


